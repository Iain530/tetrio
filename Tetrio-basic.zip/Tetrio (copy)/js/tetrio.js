$(document).ready(function() {

    var width = 300;
    var height = 460;

    var fps = 60;
    var frame = 0;

    var gravity = 0.9;
    var jumpPower = 9.3;

    var levelspeed = 30;

    var jumpingman;
    var jumpingmanImage = new Image();
    mario_src = "https://elekk.xyz/system/custom_emojis/images/000/000/009/static/mario_original_sprite_sm.png";
    jumpingmanImage.src = mario_src;

    var allBlocksImage = new Image();
    allBlocksImage.src = "/home/iain/Desktop/Projects/Tetrio/img/all.png";

    var types = ["square", "line", "T", "S", "Z", "L", "J"];
    var colours = ["red", "yellow", "pink", "orange", "blue", "green", "cyan"];

    var shapes = [];
    var controlShape;
    var fastFall = false;

    var finished = false;
    var score = 0;

    var myGameArea = {
        canvas: document.querySelector("canvas"),
        start: function() {
            this.canvas.width = width;
            this.canvas.height = height;
            this.context = this.canvas.getContext("2d");
            // Make background
            this.context.fillStyle = "black";
            this.context.fillRect(0, 0, width, height);
            this.interval = setInterval(updateGameArea, 1000 / fps);
        },
        clear: function() {
            this.context.fillStyle = "black";
            this.context.fillRect(0, 0, width, height);
        }
    };

    function jumper(colour, x, y) {
        this.colour = colour;
        this.x = x;
        this.y = y;
        this.xSpeed = 0;
        this.ySpeed = 0;
        this.grounded = true;
        this.image = jumpingmanImage;

        this.move = function() {
            this.x += this.xSpeed;
            if (this.x < 0) {
                this.x = 0;
            }
            if (this.x > width - 20) {
                this.x = width - 20;
            }

            this.ySpeed += gravity;
            this.y += this.ySpeed;
            if (this.y > height - 20) {
                this.y = height - 20;
                this.ySpeed = 0;
                this.grounded = true;
            } else {
                this.grounded = false;
            }
            checkJumperCollision(this);
        };

        this.update = function() {
            var cx = myGameArea.context;
            cx.fillStyle = this.colour;
            //cx.fillRect(this.x, this.y, 20, 20);
            cx.drawImage(jumpingmanImage, 0, 0, 19, 19, this.x, this.y, 19, 19);
        };
    }

    function block(colour, x, y) {
        this.colour = colour;
        this.x = x;
        this.y = y;

        this.imagex = colours.indexOf(this.colour) * 32;

        this.move = function(x, y) {
            this.x += x;
            this.y += y;
        }

        this.update = function() {
            var cx = myGameArea.context;
            cx.fillStyle = this.colour;
            // cx.fillRect(this.x, this.y, 19, 19);
            cx.drawImage(allBlocksImage, this.imagex, 0, 20, 20, this.x, this.y, 20, 20);
        }
    }

    function shape(colour, x, y, type) {
        this.colour = colour;
        this.x = x;
        this.y = y;
        this.type = type;
        this.landed = false;
        this.rot = 0;


        if (this.type == "square") {
            this.blocks = [
                new block(colour, x, y),
                new block(colour, x + 20, y),
                new block(colour, x, y + 20),
                new block(colour, x + 20, y + 20)
            ];
        } else if (this.type == "line") {
            this.blocks = [
                new block(colour, x - 20, y),
                new block(colour, x, y),
                new block(colour, x + 20, y),
                new block(colour, x + 40, y)
            ];
        } else if (this.type == "T") {
            this.blocks = [
                new block(colour, x - 20, y),
                new block(colour, x, y),
                new block(colour, x, y - 20),
                new block(colour, x + 20, y)
            ];
        } else if (this.type == "S") {
            this.blocks = [
                new block(colour, x - 20, y),
                new block(colour, x, y),
                new block(colour, x, y - 20),
                new block(colour, x + 20, y - 20)
            ];
        } else if (this.type == "Z") {
            this.blocks = [
                new block(colour, x - 20, y - 20),
                new block(colour, x, y - 20),
                new block(colour, x, y),
                new block(colour, x + 20, y)
            ];
        } else if (this.type == "L") {
            this.blocks = [
                new block(colour, x - 20, y),
                new block(colour, x, y),
                new block(colour, x + 20, y),
                new block(colour, x + 20, y - 20),
            ];
        } else if (this.type == "J") {
            this.blocks = [
                new block(colour, x - 20, y - 20),
                new block(colour, x - 20, y),
                new block(colour, x, y),
                new block(colour, x + 20, y)
            ];
        }

        this.rotate = function() {
            if (this.type == "line") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x + 20, this.y - 20),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x + 20, this.y + 20),
                            new block(this.colour, this.x + 20, this.y + 40)
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y + 20),
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x + 20, this.y + 20),
                            new block(this.colour, this.x + 40, this.y + 20)
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x, this.y + 40)
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x + 40, this.y)
                        ];
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            } else if (this.type == "T") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x + 20, this.y)
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x + 20, this.y)
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x - 20, this.y)
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x + 20, this.y)
                        ];
                        break;
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            } else if (this.type == "S") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x + 20, this.y + 20)
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y + 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x, this.y + 20)
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y + 20)
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y - 20),
                            new block(this.colour, this.x, this.y - 20)
                        ];
                        break;
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            } else if (this.type == "Z") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x + 20, this.y - 20),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20)
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x + 20, this.y + 20)
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y + 20),
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20)
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y - 20),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y)
                        ];
                        break;
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            } else if (this.type == "L") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x + 20, this.y + 20),
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x - 20, this.y + 20),
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y - 20),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y + 20),
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x + 20, this.y - 20),
                        ];
                        break;
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            } else if (this.type == "J") {
                switch (this.rot) {
                    case 0:
                        this.blocks = [
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x + 20, this.y - 20)
                        ];
                        break;
                    case 1:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y),
                            new block(this.colour, this.x + 20, this.y + 20)
                        ];
                        break;
                    case 2:
                        this.blocks = [
                            new block(this.colour, this.x, this.y + 20),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x, this.y - 20),
                            new block(this.colour, this.x - 20, this.y + 20)
                        ];
                        break;
                    case 3:
                        this.blocks = [
                            new block(this.colour, this.x - 20, this.y - 20),
                            new block(this.colour, this.x - 20, this.y),
                            new block(this.colour, this.x, this.y),
                            new block(this.colour, this.x + 20, this.y)
                        ];
                        break;
                    default:
                        break;
                }
                this.rot++;
                this.rot = this.rot % 4;
            }
        }

        this.move = function() {
            this.y += 20;
            var xdis;
            var ydis;

            var result = true;
            $.each(this.blocks, function(index, block) {
                if (block.y >= height - 20)
                    result = false;
            });
            if (!result) {
                this.y -= 20;
                xdis = 0;
                ydis = 0;
                this.landed = true;
            } else {
                xdis = 0;
                ydis = 20;
            }
            $.each(this.blocks, function(index, block) {
                block.move(xdis, ydis);
            });

            checkShapeCollision(this);

        }
        this.shift = function(direction) {
            if (direction == "right") {
                xdis = 20;
                this.x += 20;
            } else if (direction == "left") {
                xdis = -20;
                this.x -= 20;
            }
            $.each(this.blocks, function(index, block) {
                block.move(xdis, 0);
            });
        }
        this.update = function() {
            $.each(this.blocks, function(index, block) {
                block.update();
            });
        }
    }

    function createNewShape() {
        var i = Math.floor(Math.random() * types.length);
        var type = types[i];
        var colour = colours[i];
        var newShape = new shape(colour, 140, 0, type);
        shapes.push(newShape);
        return newShape;
    }

    function checkShapeCollision(movingShape) {
        // for
        $.each(shapes, function(index, shape) {
            if (shape != movingShape) {
                $.each(shape.blocks, function(index, block1) {
                    // loops
                    $.each(movingShape.blocks, function(index, block2) {
                        // are
                        if (block1.x == block2.x && block1.y == block2.y) {
                            // efficient
                            $.each(movingShape.blocks, function(index, moveblock) {
                                moveblock.move(0, -20);
                            });
                            movingShape.landed = true;
                            return;
                        }
                    });
                });
            }
        });

    }

    function canMove(shape, dir) {
        var result = true;
        if (dir == "left") {
            $.each(shape.blocks, function(index, block1) {
                if (block1.x <= 0)
                    result = false;

                $.each(shapes, function(index, staticShape) {
                    if (shape != staticShape) {
                        $.each(staticShape.blocks, function(index, block2) {
                            if (block1.x - 20 == block2.x && block1.y == block2.y) {
                                result = false;
                            }
                        });
                    }
                });
            });
            return result;
        } else {
            $.each(shape.blocks, function(index, block1) {
                if (block1.x >= width - 20)
                    result = false;

                $.each(shapes, function(index, staticShape) {
                    if (shape != staticShape) {
                        $.each(staticShape.blocks, function(index, block2) {
                            if (block1.x + 20 == block2.x && block1.y == block2.y) {
                                result = false;
                            }
                        });
                    }
                });
            });
            return result;
        }
    }


    function checkJumperCollision(jumper) {
        $.each(shapes, function(index, shape) {
            $.each(shape.blocks, function(index, block) {
                // stand on top
                if (block.x + 19 > jumper.x && jumper.x + 19 > block.x && block.y + 15 > jumper.y + 20 && jumper.y + 20 >= block.y && jumper.ySpeed >= 0) {
                    jumper.y = block.y - 20;
                    jumper.ySpeed = 0;
                    jumper.grounded = true;
                    // hit bottom
                } else if (block.x + 16 > jumper.x && jumper.x + 16 >= block.x && block.y + 20 > jumper.y + 5 && jumper.y + 20 >= block.y) {
                    // get squished
                    if (jumper.grounded)
                        lose();
                    // hit head on bottom while jumping
                    else {
                        jumper.y = block.y + 20;
                        jumper.ySpeed = 0;
                    }
                }
                // run into left side
                else if (block.x < jumper.x + 20 && block.x + 4 > jumper.x && block.y + 15 > jumper.y && block.y <= jumper.y + 20) {
                    jumper.x = block.x - 20;
                }
                // run into right side
                else if (block.x + 20 > jumper.x && block.x + 16 < jumper.x && block.y + 15 > jumper.y && block.y <= jumper.y + 20) {
                    jumper.x = block.x + 20;
                }

            });
        });
    }

    function lose() {
        finished = true;
        var context = myGameArea.canvas.getContext("2d");
        context.font = "30px Courier New";
        context.fillStyle = "white";
        context.fillText("Game Over!", width / 2 - 90, height / 2 - 50);
        // context.fillText("Score: " + score, width / 2 - 75, height / 2);
        // context.font = "20px Courier New";
        // context.fillText("Enter to play again", width / 2 - 115, height / 2 + 40);
    }

    function updateScore() {
        var context = myGameArea.canvas.getContext("2d");
        context.font = "20px Courier New";
        context.fillStyle = "white";
        context.fillText("Score: " + score, 5, 18);
    }

    function checkTetrisLose() {
        $.each(shapes, function(index, shape) {
            if (shape.landed && shape.y < 40) {
                $.each(shape.blocks, function(index, block) {
                    if (block.y <= 0) {
                        lose();
                    }
                });
            }
        });
    }

    function checkRows() {
        var i = height - 20;
        var tallest = i;
        var mul = 0;
        while (i >= tallest) {
            var tot = 0;
            $.each(shapes, function(index, shape) {
                $.each(shape.blocks, function(index, block) {
                    tallest = Math.min(tallest, block.y);
                    if (block.y == i) {
                        tot++;
                    }
                });
            });
            if (tot == 15) {
                removeRow(i);
                mul++;
            } else {
                i -= 20;
            }
        }
        score += 150 * mul;
    }

    function removeRow(row) {
        $.each(shapes, function(index, shape) {
            var i;
            for (i = shape.blocks.length - 1; i >= 0; i--) {
                if (shape.blocks[i].y == row) {
                    shape.blocks.splice(i, 1);
                }
            }
        });
        $.each(shapes, function(index, shape) {
            var i;
            for (i = shape.blocks.length - 1; i >= 0; i--) {
                if (shape.blocks[i].y < row) {
                    shape.blocks[i].move(0, 20);
                }
            }
        });
    }

    function updateGameArea() {
        if (finished) return;
        frame++;
        myGameArea.clear();
        if (frame % levelspeed == 0 || (fastFall && frame % 5 == 0)) {
            controlShape.move();
        }
        $.each(shapes, function(index, shape) {
            shape.update();
        });
        if (controlShape.landed) {
            checkTetrisLose();
            checkRows();
            controlShape = createNewShape();
        }
        jumpingman.move()
        jumpingman.update();

        updateScore();
    }

    function start() {
        jumpingman = new jumper("white", 10, 500);
        controlShape = createNewShape();
        myGameArea.start();
    }

    function Space(x, y) {
        this.x = x;
        this.y = y;
    }

    function canRotate(shape) {
        if (shape.type == "square")
            return false;
        var result = true;
        var spaces = [];
        if (shape.type == "line") {
            switch (shape.rot) {
                case 0:
                    if (shape.y >= height - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y - 20),
                        new Space(shape.x + 20, shape.y + 20),
                        new Space(shape.x + 20, shape.y + 40)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20 || shape.x >= width - 40) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y + 20),
                        new Space(shape.x, shape.y + 20),
                        new Space(shape.x + 40, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    if (shape.y >= height - 40) return false;
                    spaces.push(
                        new Space(shape.x, shape.y - 20),
                        new Space(shape.x, shape.y),
                        new Space(shape.x, shape.y + 40)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x < 20 || shape.x >= width - 40) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x + 20, shape.y),
                        new Space(shape.x + 40, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        } else if (shape.type == "T") {
            switch (shape.rot) {
                case 0:
                    if (shape.y > height - 40) return false;
                    spaces.push(
                        new Space(shape.x, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    spaces.push(
                        new Space(shape.x, shape.y - 20)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x > width - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        } else if (shape.type == "S") {
            switch (shape.rot) {
                case 0:
                    if (shape.y > height - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y),
                        new Space(shape.x + 20, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20) return false;
                    spaces.push(
                        new Space(shape.x, shape.y + 20),
                        new Space(shape.x - 20, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    spaces.push(
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x - 20, shape.y - 20)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x > width - 40) return false;
                    spaces.push(
                        new Space(shape.x, shape.y - 20),
                        new Space(shape.x + 20, shape.y - 20)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        } else if (shape.type == "Z") {
            switch (shape.rot) {
                case 0:
                    if (shape.y > height - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y - 20),
                        new Space(shape.x, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x + 20, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    spaces.push(
                        new Space(shape.x - 20, shape.y + 20),
                        new Space(shape.x, shape.y - 20)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x > width - 40) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y - 20),
                        new Space(shape.x + 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        } else if (shape.type == "L") {
            switch (shape.rot) {
                case 0:
                    if (shape.y > height - 40) return false;
                    spaces.push(
                        new Space(shape.x, shape.y - 20),
                        new Space(shape.x, shape.y + 20),
                        new Space(shape.x + 20, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y + 20),
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x + 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    spaces.push(
                        new Space(shape.x - 20, shape.y - 20),
                        new Space(shape.x, shape.y - 20),
                        new Space(shape.x, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x > width - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y - 20),
                        new Space(shape.x + 20, shape.y),
                        new Space(shape.x - 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        } else if (shape.type == "J") {
            switch (shape.rot) {
                case 0:
                    if (shape.y > height - 40) return false;
                    spaces.push(
                        new Space(shape.x + 20, shape.y - 20),
                        new Space(shape.x, shape.y - 20),
                        new Space(shape.x, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 1:
                    if (shape.x < 20) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x + 20, shape.y),
                        new Space(shape.x + 20, shape.y + 20)
                    );
                    result = isFree(spaces);
                    break;
                case 2:
                    spaces.push(
                        new Space(shape.x - 20, shape.y + 20),
                        new Space(shape.x, shape.y + 20),
                        new Space(shape.x, shape.y - 20)
                    );
                    result = isFree(spaces);
                    break;
                case 3:
                    if (shape.x > width - 40) return false;
                    spaces.push(
                        new Space(shape.x - 20, shape.y - 20),
                        new Space(shape.x - 20, shape.y),
                        new Space(shape.x + 20, shape.y)
                    );
                    result = isFree(spaces);
                    break;
                default:
                    break;
            }
        }
        return result;
    }

    function isFree(spaces) {
        var result = true;
        $.each(shapes, function(index, shape) {
            $.each(shape.blocks, function(index, block) {
                $.each(spaces, function(index, space) {
                    if (block.x == space.x && block.y == space.y) {
                        result = false;
                    }
                })
            });
        });
        return result;
    }

    $(document).keydown(function(key) {
        // jumpingman controls
        // Up
        if (key.which == 38 && jumpingman.grounded) {
            jumpingman.ySpeed -= jumpPower;
            jumpingman.grounded = false;
        }
        // Left
        if (key.which == 37) {
            jumpingman.xSpeed = -3;
        }
        // Right
        if (key.which == 39) {
            jumpingman.xSpeed = 3;
        }

        // Tetris controls
        // A
        if (key.which == 65) {
            if (canMove(controlShape, "left")) {
                controlShape.shift("left");
            }
        }
        // D
        if (key.which == 68) {
            if (canMove(controlShape, "right")) {
                controlShape.shift("right");
            }
        }
        // S
        if (key.which == 83) {
            fastFall = true;
        }
        // W
        if (key.which == 87) {
            if (canRotate(controlShape)) {
                controlShape.rotate();
            }
        }
    }).keyup(function(key) {
        // Left
        if (key.which == 37) {
            jumpingman.xSpeed = 0;
        }

        // Right
        if (key.which == 39) {
            jumpingman.xSpeed = 0;
        }

        if (key.which == 83) {
            fastFall = false;
        }
    });

    start();
});
